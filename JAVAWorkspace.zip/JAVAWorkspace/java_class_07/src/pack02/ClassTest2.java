package pack02;

import pack01.A;

public class ClassTest2 {

	public static void main(String[] args) {
		
		A a = new A();
		
		//B b = new B();
		// import 자체가 안됨
		
		
	}

}
