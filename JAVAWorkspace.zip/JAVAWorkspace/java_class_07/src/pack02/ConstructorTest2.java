package pack02;

import pack01.ConstructorEx;

public class ConstructorTest2 {

	public static void main(String[] args) {
		
		new ConstructorEx();
//		new ConstructorEx(1);
//		new ConstructorEx(1, 2);
//		new ConstructorEx(1, 2, 3);

	}

}
