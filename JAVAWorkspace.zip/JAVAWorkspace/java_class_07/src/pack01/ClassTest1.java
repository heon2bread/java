package pack01;

public class ClassTest1 {

	public static void main(String[] args) {
		
		A a = new A();
		
		B b = new B();

	}

}
