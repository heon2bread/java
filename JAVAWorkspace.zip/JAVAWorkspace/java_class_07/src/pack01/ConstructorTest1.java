package pack01;

public class ConstructorTest1 {

	public static void main(String[] args) {
		
		new ConstructorEx();
		new ConstructorEx(1);
		new ConstructorEx(1, 2);
		//new ConstructorEx(1, 2, 3);

	}

}
