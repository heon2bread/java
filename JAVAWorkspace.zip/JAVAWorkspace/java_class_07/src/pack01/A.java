package pack01;


// default class는 다른 패키지에서는 접근할 수 없다.
class B {
	
}


// public class는 다른 패키지에서 접근가능
public class A {

}
