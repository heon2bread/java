package inheritance;

class Parent {
	
	int parentMoney = 1000;
	public void parentMethod() {
		System.out.println("부모클래스 메소드 입니다.");
	}
	
}

class Child extends Parent { // 자식클래스
	
	int childMoney = 500;
	
	public void childMethod() {
		System.out.println("자식클래스 메소드 입니다.");
	}
	
}

public class Ex01 {

	public static void main(String[] args) {
		
		Child child = new Child(); // 자식객체 생성
		
		System.out.println("자식 필드 : " + child.childMoney);
		System.out.println("부모 필드 : " + child.parentMoney);
		System.out.println();
		
		child.childMethod();
		child.parentMethod();
		

	}

}
