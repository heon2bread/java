package inheritance;

import java.util.Scanner;

class Car {
	
	public int speed;
	public void upSpeed(int speed) {
		
		this.speed = speed;
		System.out.println("현재속도(Car클래스) : " + this.speed);
		
	}
	
}

class Genesis extends Car {
	@Override
	public void upSpeed(int speed) {
		super.speed += speed;
		if (super.speed > 200) {
			super.speed = 200;
//			System.out.println("최고 속도는 200입니다.");
//			System.out.println("200으로 초기화합니다.");
		}
		
		System.out.println("현재속도(Genesis클래스) : " + super.speed);
	}
}

// Car 클래스를 상속받은 Genesis 클래스를 만들어서
// upSpeed 메소드 재정의 하기 (최고속도 200 제한)

public class Ex04 {

	public static void main(String[] args) {
		
//		Scanner scan = new Scanner(System.in);
		Car car = new Car();
		
		Genesis genesis = new Genesis();
		
		car.upSpeed(300);
		genesis.upSpeed(300);
	

	}

}
