package poly;

// 매개변수의 다형성

class Vehicle {
	public void run() {
		System.out.println("차량이 달립니다.");
	}
}

class Bus extends Vehicle {
	
	@Override
	public void run() {
		System.out.println("버스가 달립니다.");
	}
	
	public void checkFare() {
		System.out.println("승차 요금을 체크합니다.");
	}
}

class Taxi extends Vehicle {
	@Override
	public void run() {
		System.out.println("택시가 달립니다.");
	}
}

class Driver {
	
	public void drive(Vehicle vehicle) {
		
		if(vehicle instanceof Bus) { // instanceof : 객체타입 확인 연산자
			Bus bus = (Bus)vehicle;
			bus.checkFare();
		}
		
		
		System.out.println("드라이브를 시작합니다.");
		
		vehicle.run();
	}
	
}

public class Ex04 {

	public static void main(String[] args) {

		Driver driver = new Driver();
		Bus bus = new Bus();
		Taxi taxi = new Taxi();
		
		driver.drive(bus); // 매개 변수의 다형성
		System.out.println();
		
		driver.drive(taxi);
		
	}

}