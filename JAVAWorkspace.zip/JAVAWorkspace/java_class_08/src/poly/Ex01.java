package poly;

class Parent {
	
	int parentMoney = 1000;
	
}

class Child extends Parent {
	
	int childMoney = 500;
	
}

public class Ex01 {

	public static void main(String[] args) {
		
		Parent poly = new Child(); // 자동 타입 변환 (업캐스팅)
		// 부모타입의 변수는 자식객체를 참조할 수 있다.
		// 부모 위주이다. (부모필드의 부모메소드만 접근 가능)
		
		// System.out.println(poly.childMoney);
		// 자식 멤버 접근 안됨
		
		System.out.println(poly.parentMoney);
		
		System.out.println();
		
		Child poly2 = (Child)poly; // 강제 타입변환 (다운캐스팅)
		
		System.out.println(poly2.childMoney);
		System.out.println(poly2.parentMoney);
		System.out.println();
		
		Parent Poly3 = poly2; // 자동 타입변환 (업캐스팅)
		System.out.println(poly2.parentMoney); // 부모에만 선언된 메소드만 가능하다.
		

	}

}
