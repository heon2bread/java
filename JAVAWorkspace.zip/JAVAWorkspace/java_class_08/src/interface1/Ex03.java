package interface1;

// 필드의 다형성
 interface ChickenHouse {
	 
	 public abstract void chickenCook();
	 
 }
 
 class BBQChicken implements ChickenHouse {
	 
	 @Override
	public void chickenCook() {
		System.out.println("BBQ치킨을 요리합니다.");
	}
 }
 
 class BHCChicken implements ChickenHouse {

	@Override
	public void chickenCook() {
		System.out.println("BHC치킨을 요리합니다.");
	}
 }
 
 class ChickenOrder {
	 
	 // 필드
	 public ChickenHouse chicken;
	 // 필드를 인터페이스 타입으로 설정하면 구현 객체들의 타입을 통일시켜주어
	 // 개발코드는 인터페이스의 메소드만 호출하면 된다.
	 // 즉 객체를 구현하는 코드와 객체를 사용하는 코드를 완전히 분리시켜 객체를 사용하는 코드를 수정할 필요가 없다.
	 // (유지보수가 쉬워진다.)
	 
	 public ChickenOrder(ChickenHouse chicken) {
		 this.chicken=chicken;
	 }

	 // 메소드
	 public void chickenOrder() {
		 System.out.println("치킨을 주문합니다.");
		 chicken.chickenCook();
	 }
	 
 }

public class Ex03 {

	public static void main(String[] args) {
		
		BBQChicken chicken = new BBQChicken();
		
		ChickenOrder order = new ChickenOrder(chicken);
		
		order.chickenOrder();

		System.out.println();
		
		order.chicken = new BHCChicken(); // 필드의 다형성
		
		order.chickenOrder();
		
	}

}
