package interface1;

import java.util.Scanner;

class IronMan{
	IronSuit ironSuit;
	
	public IronMan(IronSuit ironSuit) {
		this.ironSuit=ironSuit;
	}
	
	public void fight() {
		System.out.println("아이언맨이 괴물과 싸움을 시작합니다.");
		
		ironSuit.flying();
		ironSuit.attack();
		
		// 만약에 아이언슈트가 마크43이라면 레이져빔까지 쏘기
		
		if (ironSuit instanceof Mark43) {
			Mark43 mark43 = (Mark43)ironSuit;
			mark43.laserBeamAttack();
			
		}
		
	}
}

interface IronSuit {
	
	public void flying();
	
	public void attack();
	
}

class Mark1 implements IronSuit {

	String suitName = "Makr1";
	
	@Override
	public void flying() {
		System.out.println("아이언맨이 "+suitName+"을 장착하고 날아갑니다." );
	}

	@Override
	public void attack() {
		System.out.println(suitName+"을 장착한 아이언맨이 적을 향해 공격합니다.");
		
	}
	
}

class Mark43 implements IronSuit {

	String suitName = "Makr43";
	
	@Override
	public void flying() {
		System.out.println("아이언맨이 "+suitName+"을 장착하고 날아갑니다." );
	}

	@Override
	public void attack() {
		System.out.println(suitName+"을 장착한 아이언맨이 적을 향해 공격합니다.");
		
	}
	
	public void laserBeamAttack() {
		System.out.println(suitName+"을 장착한 아이언맨이 레이저빔을 쏩니다.");
	}
	
}

public class Ex06 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);

		IronMan ironMan = null;
		IronSuit ironSuit = null;
		
		System.out.println("슈트를 선택해주세요");
		System.out.println("[1] : Makr1 [2] : Mark43");
		System.out.print("선택 : ");
		int choice = scan.nextInt();
		
		if(choice==1) {
			ironSuit = new Mark1();
			
		}else if (choice==2) {
			ironSuit= new Mark43();
			
		}else {
			System.out.println("잘못 입력했습니다.");
			System.exit(0);
		}
		
		ironMan = new IronMan(ironSuit);
		
		ironMan.fight();
		
		System.out.println("승리했습니다.");
		
	}

}
