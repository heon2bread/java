package interface1;

// 인터페이스 (interface)
// 1. 추상클래스보다 훨씬 극단적이고 제한적인 성격을 갖는다.
// 2. 상수필드와 추상메소드만 정의할 수 있다. (예외있음)
// 3. 상속받으려면 implements를 사용하여야 한다.
// 4. 다중 상속이 가능하다.
// 5. 선언은 interface [이름]으로 한다.


interface Animal {
	/*public static final*/ int MAX_AGE = 500;
	
	/*public abstract*/ void sound();
	
	// 1. 모든 멤버변수는 public static final 이어야하며, 생략 가능.
	// 2. 모든 메소드는 public abstract 이어야하며, 생략 가능
	// 단) default 메소드와 static 메소드는 예외로 함 (JDK 1.8~ 이후 추가됨)
	
	public default void defaultMethod() {
		System.out.println("디폴트 메소드");
	}
	
	// default 메소드
	// 1. (JDK 1.8~) 인터페이스에 추가 가능
	// 2. 앞에 키워드 default로 명시
	// 3. 접근제한자는 public 이며, 생략 가능
	
	public static void staticMethod() {
		System.out.println("static 메소드");
	}
	
	// static 메소드
	// 1. (JDK 1.8~) 인터페이스에 추가 가능
	// 2. 접근제한자는 public 이며, 생략 가능
	
}

class Cat implements Animal {
	// 구현클래스에서는 인터페이스에 정의된 추상메소드를 반드시 오버라이딩 해야한다.
	@Override
	public void sound() {
		System.out.println("야옹~");
	}
	
}

class Dog implements Animal {
	@Override
	public void sound() {
		System.out.println("멍멍~");
	}
}


public class Ex01 {

	public static void main(String[] args) {
		
//		Animal animal = new Animal();
		// 인터페이스는 객체생성을 할 수 없다.
		Cat myCat = new Cat();
		myCat.sound();
		
		Dog myDog = new Dog();
		myDog.sound();
		
		System.out.println();
		
		Animal myAnimal = new Cat(); // 다형성
		myAnimal.sound();
		
		myAnimal = new Dog();
		myAnimal.sound();
		
		System.out.println();
		
		Animal myAnimals[] = new Animal[2]; // 객체 배열 생성
		myAnimals[0] = new Cat();
		myAnimals[1] = new Dog();
		
		myAnimals[0].sound();
		myAnimals[1].sound();
		
		System.out.println();
		
		Animal myDuck = new Animal() {
			
			@Override
			public void sound() {
				System.out.println("꽥꽥~");
			}
		};
		
		myDuck.sound();
		
	}

}
