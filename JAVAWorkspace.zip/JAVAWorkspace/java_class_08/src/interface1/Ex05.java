package interface1;

import java.util.Scanner;

class Person {
	private String name;
	private int age;
	private String tel;
	private String address;
	
	// 초기화 생성자
	public Person(String name, int age, String tel, String address) { // alt+shift+s
		super();
		this.name = name;
		this.age = age;
		this.tel = tel;
		this.address = address;
	}
	// 필드를 출력하는 profile 메소드 만들기
	public void profile() {
		System.out.println("###################################");
		System.out.println("이름 : "+name);
		System.out.println("나이 : "+age);
		System.out.println("전화번호 : "+tel);
		System.out.println("주소 : "+address);
		System.out.println("###################################");
	}
}
	
interface PersonService {
	
	public void personList(Person[] persons);
	
	public Person[] personInsert(int personSu);
	
}

class PersonServiceImpl implements PersonService {

	Scanner scan = new Scanner(System.in);
	
	@Override
	public void personList(Person[] persons) {
		// Person배열을 매개변수로 받아서
		// 배열안에 Person 객체의 profile 메소드 호출하기
		for (int i = 0; i < persons.length; i++) {
			persons[i].profile();
			
		}
		
	}

	@Override
	public Person[] personInsert(int personSu) {
		// 정수하나의 매개변수로 받아 그 수만큼의 길이의 Person 배열을 생성한 후
		// 반복문으로 이름, 나이, 전화번호, 주소를 입력 받아 Person 객체 생성 후에 Person 배열의 각 요소에 저장
		// Person 배열을 반환
		
		Person[] persons = new Person[personSu];
		for (int i = 0; i < personSu; i++) {
			System.out.println(i+1+"번째 사람의 정보를 입력해주세요");
			
			System.out.print("이름 입력 : ");
			String name = scan.next();
			
			System.out.print("나이 입력 : ");
			int age = scan.nextInt();
			
			System.out.print("전화번호 입력 : ");
			String tel = scan.next();
			
			System.out.print("주소 입력 : ");
			String address = scan.next();
			
			persons[i] = new Person(name, age, tel, address);
			
		
			
		}
		
		return persons;
	}
	
}
	


public class Ex05 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		PersonService service = new PersonServiceImpl();
		
		Person[] persons = service.personInsert(3);
		
		service.personList(persons);

	}

}
