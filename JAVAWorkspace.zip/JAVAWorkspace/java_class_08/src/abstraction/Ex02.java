package abstraction;

abstract class Worker {
	
	String name;
	
	public Worker(String name) {
		this.name=name;
	
	}
	public abstract void work();
	
	public abstract void eat();
	
}

// Worker 클래스를 상속받는 TaxiDriver 클래스를 만든 후
// 추상메소드를 오버라이딩하여 메소드 재정의 하기
class TaxiDriver extends Worker {
	
	public TaxiDriver(String name) {
		super(name);
	}
	@Override
	public void work() {
		System.out.println(name + "이(가) 택시를 운행합니다.");
	}
	@Override
	public void eat() {
		System.out.println(name + "이(가) 기사식당에 가서 식사를 합니다.");
	}
}


// Worker 클래스를 상속받는 Cleaner 클래스를 만든 후
// 추상메소드를 오버라이딩하여 메소드 재정의 하기
class Cleaner extends Worker {
	public Cleaner(String name) {
		super(name);
	}
	@Override
	public void work() {
		System.out.println(name + "이(가) 건물을 청소합니다.");
	}
	@Override
	public void eat() {
		System.out.println(name + "이(가) 구내식당에 가서 식사를 합니다.");
	}
}

public class Ex02 {

	public static void main(String[] args) {
		
		TaxiDriver taxiDriver = new TaxiDriver("홍길동");
		taxiDriver.work();
		taxiDriver.eat();
		System.out.println();
		
		Cleaner cleaner = new Cleaner("성춘향");
		cleaner.work();
		cleaner.eat();
		
	}

}
