package abstraction;

abstract class Animal { // 추상클래스
	
	public void eat() {
		System.out.println("냠냠");
	}
	
	public abstract void sound(); // 추상메소드 {} 불가
	// 실제 구현은 자식클래스에서 한다.
	
}
 
class Cat extends Animal {
	
	// 자식클래스에서 부모의 추상메소드는 강제 오버라이딩
	@Override
	public void sound() {
		System.out.println("야옹~");
	}
	
}

class Dog extends Animal {
	
	@Override
	public void sound() {
		System.out.println("멍멍~");
	}
}

public class Ex01 {

	public static void main(String[] args) {
		
//	Animal animal = new Animal();
	// 추상클래스는 객체생성을 할 수 없음.
		Cat myCat = new Cat();
		myCat.eat();
		myCat.sound();
		System.out.println();
		
		Dog myDog = new Dog();
		myDog.eat();
		myDog.sound();
		
		Animal myDuck = new Animal() {// 익명 자식클래스 (일회용)
			
			@Override
			public void sound() {
				System.out.println("꽥꽥~");
				}
			};
			
			myDuck.sound(); 
		}

}