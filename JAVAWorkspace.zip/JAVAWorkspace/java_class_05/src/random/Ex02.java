package random;

import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		while (true) {

			System.out.println("숫자 하나를 선택해주세요");
			System.out.println("------------------------------");
			System.out.println("## (1)가위 (2)바위 (3)보 (4)종료 ##");
			System.out.println("------------------------------");

			int myChoice = scan.nextInt();

			String myStr = " ";

			switch (myChoice) {

			case 1:
				myStr = "가위";
				break;
			case 2:
				myStr = "바위";
				break;
			case 3:
				myStr = "보";
				break;
			case 4:
				System.out.println("게임을 종료합니다.");
				System.exit(0); // 프로그램 강제종료

			default:
				System.out.println("잘못 입력 하였습니다.");
				continue;

			}
			
			int comChoice = (int)(Math.random()*3)+1;
			
			String comStr = " ";
			
			switch (comChoice) {
			
			case 1 :
				comStr = "가위";
				break;
			case 2 :
				comStr = "바위";
				break;
			case 3 : 
				comStr = "보";
				break;
			
			}

			System.out.println("나 : "+ myStr);
			System.out.println("컴퓨터 : "+ comStr);
			
			// 승리 / 무승부 / 패배 >> 출력
			// 1. 가위 2. 바위 3. 보
			
			if( (myChoice==1 && comChoice==3)
				|| (myChoice==2 && comChoice==1)
				|| (myChoice==3 && comChoice==2)) {
				System.out.println("----------");
				System.out.println("# 승리입니다! #");
				System.out.println("----------");
			}else if (myChoice==comChoice) {
				System.out.println("----------");
				System.out.println("# 무승부입니다! #");
				System.out.println("----------");}
				else {
					
					System.out.println("----------");
					System.out.println("# 패배입니다! #");
					System.out.println("----------");
				}
			}
	
			
			}	
	
			



			
		}
