package array;

public class Ex03 {

	public static void main(String[] args) {
		
		// 1. 길이가 5인 int 타입 배열 생성하기
		// 2. index를 사용해서 각 배열의 요소에 100, 200, 300, 400, 500 값 저장하기
		// 3. 배열의 각 요소를 출력하기
		
		int intArray[] = new int[5];
		intArray = new int[] {100,200,300,400,500}; 
//		intArray[0] = 100;
//		intArray[1] = 200;
//		intArray[2] = 300;
//		intArray[3] = 400;
//		intArray[4] = 500;
		
//		System.out.println(intArray[0]);
//		System.out.println(intArray[1]);
//		System.out.println(intArray[2]);
//		System.out.println(intArray[3]);
//		System.out.println(intArray[4]);
		
		for (int i=0; i<5; i++) { // i : 인덱스 제어변수

			System.out.println(intArray[i]);
			
		}
		
		System.out.println("배열의 길이는 ? : "+intArray.length);
		// 배열의 길이 구하는 방법 : 배열변수.length
		
		for(int i=0; i < intArray.length; i++) {
			System.out.println(intArray[i]);
		}

	}

}
