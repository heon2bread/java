package array;

import java.util.Scanner;

public class Ex06 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int scores[] = new int[5];
		
		int sum=0;
		double avg = 0.0;
		
		// 배열과 for문을 사용하여 5명의 점수를 입력받아 배열의 각 요소에 저장하기
		// 각 학생의 점수를 출력하고 총 점수의 합과 평균 구하기
		
		for (int i=0; i<5; i++) {
			System.out.println(i+1+"번째 학생의 점수를 입력하세요.");
			scores[i]=scan.nextInt();
			sum+=scores[i];
		}
		for (int i =0; i<5; i++) {
			
			System.out.println(i+1+"번째 학생 점수 : "+scores[i]+"점");
			
		}
		avg=sum/5;
		System.out.println("총점 : "+sum+"점\n평균 : "+avg+"점");

	}

}
