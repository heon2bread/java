package array;

import java.util.Scanner;

public class Ex11 {

	public static void main(String[] args) {
		
		// 행과 열의 길이를 입력받아 int 타입의 2차원 배열을 생성하고
		// 1부터 하나씩 숫자를 증가하여 배열의 각 요소에 저장 후 출력하기
		// 예) 2행 3열
		// 1  2  3
		// 4  5  6
	Scanner scan = new Scanner(System.in);
	
	int row, col;
	// 행, 열
	System.out.print("행 갯수를 입력 : ");
	row = scan.nextInt();
	
	System.out.print("행 갯수를 입력 : ");
	col = scan.nextInt();
	
	int [][] array = new int[row][col];
	
	int value = 1;
	
	for (int i = 0; i < array.length; i++) {
		
		for (int j = 0 ; j < array[i].length; j++) {
			
			array[i][j] = value;
			value++;
			System.out.printf("%d\t",array[i][j]);
			
		}
		
		System.out.println();
	}
		scan.close();
		
		
		

	}

}
