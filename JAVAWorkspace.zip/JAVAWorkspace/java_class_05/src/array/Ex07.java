package array;

import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);

		String name[] = new String[3];
		
		int kor[] = new int[3];
		int eng[] = new int[3];
		int total[] = new int[3];
		int rank[] = new int[3];
		
		
		// 1. for문을 사용하여 각 학생의 이름, 국어점수, 영어점수를 입력받아 배열의 각 요소에 저장하기 (총점 구하기)
		// 2. 순위 구하기 (이중 for문, if문)
		// 총점을 비교 후에 총점이 가장 높은 학생은 1등 
		// 총점이 두번째로 높은 학생은 2등
		// 총점이 가장 낮은 학생은 3등
		
		for(int i = 0; i<3; i++) {
			System.out.print(i+1+"번째 학생의 이름\n");
			name[i]=scan.next();
			System.out.print(i+1+"번째 학생의 국어 점수\n");
			kor[i]=scan.nextInt();
			System.out.print(i+1+"번째 학생의 영어 점수\n");
			eng[i]=scan.nextInt();
			
			total[i] = kor[i] + eng[i];
		}
		for (int i=0; i<3; i++) {
			rank[i] = 1;
			for (int j=0; j<3; j++) {
				if(total[i] < total[j]) {
					rank[i]++;
				}
				
			}
		}
		for(int i=0; i<3; i++) {
			System.out.printf("%s님의 총점은 %d점이고, 순위는 %d등 입니다.\n", name[i], total[i], rank[i]);
		}

	}

}
