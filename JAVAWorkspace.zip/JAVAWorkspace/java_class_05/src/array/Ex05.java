package array;

import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		
		int array[] = new int[5];
		
		Scanner scan = new Scanner(System.in);
		
		// 정수 5개를 입력받아 배열의 각 요소에 저장하기
		for(int i=0; i<5; i++) {
			
			System.out.print(i+1 + "번째 정수 입력 : ");
			array[i] = scan.nextInt();
			
		}
		
		// 배열의 각 요소를 출력하기
		for(int i=0; i<5 ; i++) {
			
			if(array[i]%3==0) {
			System.out.println("array[" + i + "] : " + array[i]);
		}
		
		
		}
	}
	
}

