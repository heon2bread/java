package array;

import java.util.Scanner;

public class Ex12 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("방의 갯수 입력 : ");
		
		int roomSu = scan.nextInt();
		
		boolean[] room = new boolean[roomSu];
		// false : 빈방, true : 사용 중
		
		while (true) {
			
			System.out.println("-----------------------------");
			System.out.println("## 1.입실 2.퇴실 3.보기 4.종료 ##");
			System.out.println("-----------------------------");			
			System.out.println("선택 : ");
			int choice = scan.nextInt();
			
			switch (choice) {
			case 1:
				int inRoom;
				do {
					System.out.println("입실 할 방의 번호 입력 : ");
					inRoom = scan.nextInt();
					
				} while(inRoom<1 || inRoom>roomSu);
				// 방의 번호가 1보다 작거나 방의 갯수보다 크다면 다시 입실 할 방의 번호 입력받게 한다.
				if (room[inRoom-1]) {
					System.out.println(inRoom + "호실은 이미 사용중 입니다.");
				}else {
					System.out.println(inRoom + "호실에 입실 하였습니다.");
					room[inRoom-1] = true;
				}
				break;
			case 2: 
				int outRoom;
				
				do {
					System.out.println("퇴실 할 방의 번호 입력 : ");
					outRoom = scan.nextInt();
				}while(outRoom<1 || outRoom>roomSu);
				if (!room[outRoom-1]) { // ! : 논리 부정연산자
					System.out.println(outRoom+"호실은 이미 빈방입니다.");}
					else {
						System.out.println(outRoom+"호실에서 퇴실하셨습니다.");
						room[outRoom-1] = false;
				}
				break;
			case 3: 
				for (int i=0; i < room.length; i++) {
					if (room[i]) {
					System.out.println(i+1+"호실은 사용중인 방입니다.");}
					else {
						System.out.println(i+1+"호실은 빈방 입니다.");
					}
				}
				break;
			case 4:
				System.out.println("프로그램 종료합니다.");
				System.exit(0); // 프로그램 강제 종료
				default :
				System.out.println("잘못 입력하였습니다.");
			}
			
			
		}

	}

}
