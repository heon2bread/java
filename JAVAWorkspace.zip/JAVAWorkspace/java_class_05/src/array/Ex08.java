package array;

import java.util.Scanner;

public class Ex08 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int num[] = new int[5];
		
		// 1. 5개의 숫자를 입력받아 num 배열의 각 요소에 저정하기
		
		int temp = 0;
		
		// 2. 이중 for문을 사용해서 num 배열의 인덱스 0부터 작은수로 만들기 (이중 for문, if문, temp변수)

		for(int i=0; i<5; i++) {
			System.out.println(i+1+"번째 숫자를 입력하세요");
			num[i] = scan.nextInt();
			
		
		}
		
		for(int i=0; i<5; i++) {
			for(int j = i+1; j<5; j++) {
				if (num[i]>num[j]) {
					temp=num[i];
					num[i]=num[j];
					num[j]=temp;
					
				}
			}
		}
		
		System.out.printf("%d, %d, %d, %d, %d\n",num[0], num[1], num[2],num[3],num[4]);
		
		scan.close();

	}

}
