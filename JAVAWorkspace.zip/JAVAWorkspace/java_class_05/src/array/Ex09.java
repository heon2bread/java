package array;

public class Ex09 {

	public static void main(String[] args) {
		
		int[] scores = {80, 93, 77, 69, 85};
		
		for(int i : scores) { // 향상된 for문
			System.out.print(i+"  ");
		}
		System.out.println();
		
		
		// 학생이 2명이 늘어났다면...
		int [] newScores = new int[7];
		
		for(int i =0 ; i<scores.length; i++) {
			
			newScores[i] = scores[i];
		}
		
		// newScores 배열의 요소를 향상된 for문으로 출력하기
		
		for(int a : newScores) {
			System.out.print(a+"  ");
		}

	}

}
