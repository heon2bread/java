package expression;

import java.util.regex.Pattern;

public class Ex04 {

	public static void main(String[] args) {
		
		String pattern = "[가-힣]+";
		
		String koreaName = "홍길동";
		
		if (Pattern.matches(pattern, koreaName)) {
			System.out.println("올바른 한국이름 입니다.");
		} else {
			System.out.println("올바른 한국이름이 아닙니다.");
		}

		String pattern2 = "[A-Z][a-zA-Z]*";
		
		String engName = "Hong";
		
		if (Pattern.matches(pattern2, engName)) {
			System.out.println("올바른 영어이름 입니다.");
		}else {
			System.out.println("올바른 영어이름이 아닙니다.");
		}
		
	}

}