package expression;

import java.util.Scanner;
import java.util.regex.Pattern;

class Member {
	
	private String name;
	private int age;
	private String tel;
	private String email;
	
	public Member(String name, int age, String tel, String email) {
		super();
		this.name = name;
		this.age = age;
		this.tel = tel;
		this.email = email;
	}
	
	public void memberProfile() {
		System.out.println("##########################################");
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("전화번호 : " + tel);
		System.out.println("이메일 : " + email);
		System.out.println("##########################################");
		
	}
	
	
	
}

public class Ex05 {

	public static void main(String[] args) {
		
		// Scanner를 사용해서 이름, 나이, 전화번호, 이메일 입력받기
		// 이름, 전화번호, 이메일 > 문자열
		// 나이 > 정수
		// 이름, 전화번호, 이메일은 정규 표현식을 사용해서 올바르게 입력 받았는지 체크
		// 나이는 if문 사용해서 올바르게 입력 받았는지 체크
		// 20살부터 60살까지만 제한
		// 모두 올바르게 입력 받았다면 Member 객체 생성 후 memberProfile 메소드 호출하기
		Scanner scan = new Scanner(System.in);
		
		System.out.println("프로필을 등록하기 위한 이름, 나이, 전화번호, 이메일을 입력해주세요");
		
		System.out.print("이름 입력 : ");
		String name = scan.next();
		
		boolean nameCheck = Pattern.matches("[가-힣]+", name);
		
		boolean ageCheck;
		System.out.print("(20살~60살까지 가능)나이 입력 : ");
		int age = scan.nextInt();
		if(age<20 || age > 60) {
			ageCheck = false;
		} else {
			ageCheck = true;
		}
		
		System.out.print("전화번호 입력 : ");
		String tel = scan.next();
		
		System.out.print("이메일 입력 : ");
		String email = scan.next();
		
		boolean telCheck = Pattern.matches("\\d{2,3}-\\d{3,4}-\\d{4}",tel);
		
		
		boolean emailCheck = Pattern.matches("\\w+@\\w+\\.\\w+(\\.\\w+)?",email);
		
		if (nameCheck && ageCheck && telCheck && emailCheck) {
			Member member = new Member(name,age, tel, email);
			System.out.println("프로필이 등록되었습니다!");
			member.memberProfile();
		}else {
			System.out.println("프로필이 등록되지 않았습니다!");
		}
		
		
		
		
		
		
		
		

	}

}
