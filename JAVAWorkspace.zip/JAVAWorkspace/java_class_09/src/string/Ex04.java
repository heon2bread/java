package string;

public class Ex04 {

	public static void main(String[] args) {
		
		String str = "Hello World";
		
		// charAt : 해당 위치의 문자하나를 char 형으로 반환
		char ch = str.charAt(6);
		System.out.println(ch);
		
		// isEmpty : 해당 변수가 비어있으면 true 반환. 아니면 false 반환
		boolean bool = str.isEmpty();
		System.out.println(bool);

		// length : 문자열의 길이를 정수로 반환
		int length = str.length();
		System.out.println(length);
		
		// toCharArray : 문자열을 한글자씩 char 배열로 반환
		char[] charArray = str.toCharArray();
		
		for (char c : charArray) {
			System.out.print(c + " ");
		}
		System.out.println();
		
		// replace : 문자열을 교체해준다.
		System.out.println(str.replace("Hello", "Hi"));
		
	}

}
