package string;

public class Ex05 {

	public static void main(String[] args) {
		
		String str = "Hello Java";
		
		// indexOf : 문자열에 저장한 문자가 처음 몇번째에 있는지를 반환
				System.out.println(str.indexOf("a"));
				
		// lasyIndexOf : 문자열에 지정한 문자가 마지막 몇번째에 있는지를 반환
				System.out.println(str.lastIndexOf("a"));
				
		// split : 지정한 문자로 문자열을 나눌 수 있다. (배열로 반환)
				String str2 = "A:B:C:Hello:World";
				
				String[] split = str2.split(":");
				for (String s : split) {
					System.out.print(s+" ");
				}
				
		// substring : 문자열에 지정한 범위에 속하는 문자열을 반환
				String str3 = "ABCDEFG";
				String substring = str3.substring(0,2);
				// index 0부터 1까지(2는 불포함) 문자열을 반환
				System.out.println();
				System.out.println(substring);
				
				

	}

}
