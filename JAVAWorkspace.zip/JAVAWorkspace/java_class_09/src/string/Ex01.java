package string;

import java.util.Scanner;

public class Ex01 {

	public static void main(String[] args) {
		
		// String은 클래스이다.
		// 문자열은 굉장히 많이 쓰이기 때문에 자바에서는 
		// String 클래스를 기본형과 같은 형식으로 쓸 수 있도록 해두었다.
		
		String str1 = "Hello";
		String str2 = "Hi";
		String str3 = "Hello";
		
		System.out.println(str1 == str2); // false
		System.out.println(str1 == str3); // true 같은 번지수
		System.out.println();
		
		String str4 = new String("JAVA");
		String str5 = new String("JAVA");

		System.out.println(str4==str5); // false 다른 객체, 다른 번지수
		System.out.println("str4, str5 문자열 비교 : "+str4.equals(str5));
		// .equals : 원본 객체와 매개값으로 주어진 객체의 문자열을 비교 후에
		// 문자열이 같으면 true, 문자열이 다르면 false 반환
		
		System.out.println("\nQUIZ : 아버지를 아버지라고 부르지 못하는 인물은??");
		
		// Scanner를 사용해서 정답을 입력받은 후 
		// 정답이 홍길동 이라면 정답입니다. 출력
		// 아니라면 정답이 아닙니다. 출력
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("정답 입력 : ");
		String answer = scan.next();
		
		if (answer.equals("홍길동")) {
			System.out.println("정답입니다.");
		}else {
			System.out.println("정답이 아닙니다.");
		}

		
	}

}