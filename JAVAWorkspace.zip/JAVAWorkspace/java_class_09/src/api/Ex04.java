package api;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		
		// Math 클래스는 수학 함수를 사용하는데 있어 편리한 기능을 제공해주는 클래스
		// Math 클래스의 모든 메소드는 정적으로 구성되어 있어 클래스로 편하게 접근 가능하다.
		
		int a = Math.abs(-10);
		// abs 메소드는 인자로 넘긴 데이터의 절대값을 반환
		System.out.println("a의 절대값 Math.abs(-10) : "+a);
		
		int b = Math.max(1, 9);
		// max 메소드는 전달된 데이터 중에 더 큰 수를 반환
		System.out.println("Math.max(1, 9) / 1,9 중에 더 큰 수 = b = "+b);
		
		int c = Math.min(1, 9);
		// min 메소드는 전달된 데이터 중에 더 작은 수를 반환
		System.out.println("Math.min(1, 9) / 1,9 중에 더 작은 수 = c = "+c);
		
		double d = Math.ceil(1.1);
		// 전달된 데이터를 올림하여 반환
		System.out.println("Math.ceil(1.1의 올림값) : "+d);
		
		double e = Math.floor(9.9);
		// 전달된 데이터를 버림하여 반환
		System.out.println("Math.floor(9.9의 버림값) : "+e);

		long f = Math.round(5.3);
		long g = Math.round(5.7);
		// 전달된 데이터를 반올림하여 반환
		System.out.println("Math.round(5.3의 반올림 값) : "+f);
		System.out.println("Math.round(5.7의 반올림 값) : "+g);
		
		// Scanner를 사용해서 3개의 정수를 입력받아
		// 3개의 정수의 최대값, 최소값 구하기 (Math클래스 사용)
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("첫번째 정수 입력 : ");
		int num1 = scan.nextInt();
		System.out.print("두번째 정수 입력 : ");
		int num2 = scan.nextInt();
		System.out.print("세번째 정수 입력 : ");
		int num3 = scan.nextInt();
		
		int max, min;
		
		max = Math.max(num1, num2);
		
		max = Math.max(max, num3);
		
		min = Math.min(num1, num2);
		
		min = Math.min(min, num3);
		
		System.out.println("최대값 : "+max);
		System.out.println("최소값 : "+min);

	
	}

}
