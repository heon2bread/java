package api;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Ex07 {

	public static void main(String[] args) {
		
		Date now = new Date();
		// 현재 시스템의 시간을 객체를 생성
		// 그 외는 잘 사용하지 않음.
		
		System.out.println(now.toString());
		
		SimpleDateFormat simpleFormat1 = new SimpleDateFormat("yyyy년 MM월 dd일");
		SimpleDateFormat simpleFormat2 = new SimpleDateFormat("a hh시 mm분 ss초");
		
		String date = simpleFormat1.format(now);
		String time = simpleFormat2.format(now);
		
		System.out.println("오늘의 날짜 : " + date);
		System.out.println("현재 시간 : " + time);
		
		Calendar cal = Calendar.getInstance();
		// Calendar 클래스는 추상 클래스로서 객체를 직접 생성하지 않음
		
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH)+1;
		// 컴퓨터의 월은 0부터 시작하기 때문에 +1을 해주어야 한다.
		
		int day = cal.get(Calendar.DAY_OF_MONTH);
		
		System.out.printf("오늘의 날짜 : %d년 %d월 %d일", year, month, day);
		
		int hour = cal.get(Calendar.HOUR); // 12시간제
		cal.get(Calendar.HOUR_OF_DAY); // 24시간제
		int minute = cal.get(Calendar.MINUTE);
		int second = cal.get(Calendar.SECOND);
		System.out.println();
		System.out.printf("현재 시간 : %d시 %d분 %d초", hour, minute, second);
		
		
	}

}
