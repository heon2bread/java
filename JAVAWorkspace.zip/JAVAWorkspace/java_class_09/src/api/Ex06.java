package api;

import java.util.Arrays;

public class Ex06 {

	public static void main(String[] args) {
		
		int[] array = {1,2,3,4,5};
	
		// toString : 매개값으로 전달받은 배열의 요소를 문자열로 반환
		System.out.println(Arrays.toString(array));
		
		int[] array2 = Arrays.copyOf(array, 7);
		// 배열 복사 : copyOf(복사 할 배열, 길이);
		// 길이만큼 새로운 배열이 만들어지고 복사 힐 배열의 index 0부터 복사가 된다.
		System.out.println(Arrays.toString(array2));
		for (int i : array2) {
			System.out.print(i+" ");
		}
		System.out.println();
		
		int[] array3 = Arrays.copyOfRange(array, 2, 4);
		// index 2부터 3까지 (4는 불포함)의 배열이 복사가 된다.
		System.out.println(Arrays.toString(array3));
		
		int[] intArray = {4, 1, 3, 7, 2, 5, 6};
		
		Arrays.sort(intArray);
		// sort 메소드는 전달받은 배열의 모든 요소를 오름차순으로 정렬한다.
		System.out.println(Arrays.toString(intArray));
		
		
		
		

	}

}
