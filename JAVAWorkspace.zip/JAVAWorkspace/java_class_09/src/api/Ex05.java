package api;

import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		
		String str = "1 java 2 java red java blue java";
		
		Scanner scan = new Scanner(str);
		
		scan.useDelimiter("\\s*java\\s*");
		// java 키워드로 데이터를 분류 할 수 있다.
		
		System.out.println(scan.nextInt()); // 1
		System.out.println(scan.nextInt()); // 2 
		System.out.println(scan.next()); // red
		System.out.println(scan.next()); // blue
		
	}

}
