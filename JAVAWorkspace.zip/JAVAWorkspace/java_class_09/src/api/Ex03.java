package api;

import java.util.Random;

public class Ex03 {

	public static void main(String[] args) {
		
		Random r = new Random(System.currentTimeMillis());
		
		// System.currentTimeMillis(); 로 해서 종자값이 다르게 한다.
		
		System.out.println(r.nextInt());
		System.out.println(r.nextLong());
		System.out.println(r.nextFloat());
		System.out.println(r.nextDouble());
		System.out.println(r.nextBoolean());
		
		byte[] byteArray = new byte[3];
		
		r.nextBytes(byteArray);
		// byte[]에 byte타입 난수를 발생시켜 채워준다.
		
		for (byte b : byteArray) {
			System.out.print(b+" ");
		}

	}

}
