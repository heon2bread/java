package api;

import java.util.Objects;

class Person {
	
	private String name;
	private int age;
	private String SSN;
	public Person(String name, int age, String sSN) {
		super();
		this.name = name;
		this.age = age;
		SSN = sSN;
	}
	
	// 데이터가 같을때에 같은 hashCode 값을 얻기 위해 오버라이딩
	@Override
	public int hashCode() {
		return Objects.hash(SSN, age, name);
	}
	
	// 데이터가 같을때에 true를 반환하도록 오버라이딩
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return Objects.equals(SSN, other.SSN) && age == other.age && Objects.equals(name, other.name);
	}

	// 가치있는 정보를 얻기 위해 오버라이딩
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", SSN=" + SSN + "]";
	}
	
	
	
	
}

public class Ex01 {

	public static void main(String[] args) {
		
		Person person1 = new Person("홍길동",20,"123456-1234567");
		
		Person person2 = new Person("홍길동",20,"123456-1234567");
		
		System.out.println(person1.equals(person2));
		
		System.out.println(person1.hashCode());
		System.out.println(person2.hashCode());

		System.out.println(person1.toString());
		
	}

}