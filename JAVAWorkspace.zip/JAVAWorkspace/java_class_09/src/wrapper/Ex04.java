package wrapper;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		
		// 문자열을 기본타입의 값으로 변환
		
//		String str = "100";
//		
//		int value = Integer.parseInt(str); // 정수값 변환
//		
//		System.out.println(value);
		
		// Scanner 로 나이를 문자열로 입력받아
		// 20살 이상이면 성인입니다.
		// 20살 미만이면 미성년자입니다.
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("나이 입력 : ");
		String str = scan.next();
		int age = Integer.parseInt(str);
		
		if (age >= 20) {
			System.out.println(age+"살 : 성인입니다.");
		}else {
			System.out.println(age+"살 : 미성년자입니다.");
		}
		

	}

}
