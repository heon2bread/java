package wrapper;

public class Ex02 {

	public static void main(String[] args) {
		
		// 자동 박싱
		Integer obj = 100;
		
		// 자동 언박싱
		int value = obj + 200;
		
		System.out.println(value);
		
		printDouble(new Double(3.14));
		
		printDouble(3.141592); // 자동 박싱

	}
	
	public static void printDouble(Double obj) {
		System.out.println(obj.doubleValue());
	}

}
