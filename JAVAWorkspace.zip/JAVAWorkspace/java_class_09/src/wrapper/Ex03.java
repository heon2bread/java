package wrapper;

public class Ex03 {

	public static void main(String[] args) {
		
		Integer obj1 = new Integer(100);
		Integer obj2 = new Integer(100);
		
		
		// 객체간의 비교
		System.out.println(obj1 == obj2);
		
		System.out.println(obj1.equals(obj2));
		// equals : 데이터비교
		// 원본 객체의 데이터와 매개값으로 주어진 객체의 데이터를 비교 후 
		// 데이터가 같다면 true 반환, 다르다면 false 반환.

		
		
	}

}
