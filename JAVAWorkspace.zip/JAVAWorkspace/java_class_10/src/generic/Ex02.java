package generic;

class Box<E> {
	
	private E obj;

	public E getObj() {
		return obj;
	}

	public void setObj(E obj) {
		this.obj = obj;
	}
	
}

public class Ex02 {

	public static void main(String[] args) {
	
//		Box box = new Box();
//		
//		box.setObj("안녕하세요");
//		
//		String str = (String)box.getObj();
//		
//		System.out.println(str);
		
		Box<Integer> box = new Box<Integer>();
		
		box.setObj(12345);
		int value1 = box.getObj();
		System.out.println(value1);
		
		Box<String> box2 = new Box<String>();
		
		box2.setObj("Hello World");
		String str2 = box2.getObj();
		System.out.println(str2);
			
		
		
	}

}
