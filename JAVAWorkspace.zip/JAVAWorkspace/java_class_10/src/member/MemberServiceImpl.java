package member;

import java.util.*;

public class MemberServiceImpl implements MemberService {
	
	private ArrayList<Member> list = new ArrayList<>();
	
	private Scanner scan = new Scanner(System.in);

	
	@Override
	public void memberList() {
		// 전체 회원 목록을 출력
		System.out.println("-------- 전체 회원 목록 --------");
		for (int i = 0 ; i < list.size(); i++) {
			Member member = list.get(i);
			member.profile();
		}
		System.out.println("-----------------------------");
	}

	@Override
	public void memberInsert() {
		// 이름, 나이, 전화번호를 입력받아 회원 등록
		System.out.print("이름 : ");
		String name = scan.next();
		System.out.print("나이 : ");
		int age = scan.nextInt();
		System.out.print("전화번호 : ");
		String tel = scan.next();
		
		list.add(new Member(name,age,tel));

	}

	@Override
	public void memberView() {
		// 이름을 입력받아 해당 회원의 나이와, 전화번호 출력
		System.out.print("이름 :");
		String name = scan.next();
		
		for (int i = 0; i < list.size(); i++) {
			Member view = list.get(i);
			
			if (view.getName().equals(name)) {
				System.out.println(name + "님의 나이는 : "+view.getAge()+"살");
				System.out.println(name + "님의 전화번호 : "+view.getTel()+"번");
				return;
			}
		}
		System.out.println(name + "님은 저희 회원이 아닙니다.");
	
	}

	@Override
	public void memberEdit() {
		// 이름을 입력받아 해당 회원의 나이와, 전화 번호를 수정
		System.out.print("이름 :");
		String name = scan.next();
		
		for (int i =0; i < list.size(); i++) {
			Member edit = list.get(i);
			
			if (edit.getName().equals(name)) {
				System.out.print("수정 할 나이 : ");
				int age = scan.nextInt();
				System.out.print("수정 할 전화번호 : ");
				String tel = scan.next();
				
				edit.setAge(age);
				edit.setTel(tel);
				
				System.out.println(name + "님의 나이와 전화번호를 수정하였습니다.");
				return;
				
			}
		}
		System.out.println(name+"님은 저희 회원이 아닙니다.");
		
	
	}

	@Override
	public void memberDelete() {
		// 이름을 입력 받아 해당 회원을 삭제
		System.out.print("이름 :");
		String name = scan.next();
		
		for (int i = 0; i < list.size(); i++) {
			Member delete = list.get(i);
			
			if (delete.getName().equals(name)) {
				list.remove(i);
				System.out.println(name+"회원을 삭제하였습니다.");
				return;
				
			}
		}
		System.out.println(name+"님은 저희 회원이 아닙니다.");

	}

}
