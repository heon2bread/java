package member;

import java.util.Scanner;

public class MemberMain {

	public static void main(String[] args) {

		MemberService service = new MemberServiceImpl();
		Scanner scan = new Scanner(System.in);
		
		while(true) {
			System.out.println("######## 회원 관리 프로그램 ########");
			System.out.println("## 1.회원 목록  2.회원 조회  3.회원 등록 ##");
			System.out.println("## 4.회원 수정  5.회원 삭제  6.종료 ##");
			System.out.println("################################");
			System.out.println();
			System.out.print("선택 : ");
			
			int choice = scan.nextInt();
			
			switch (choice) {
				
				case 1 : 
					service.memberList();
					break;
				case 2 :
					service.memberView();
					break;
				case 3 :
					service.memberInsert();
					break;
				case 4 :
					service.memberEdit();
					break;
				case 5 :
					service.memberDelete();
					break;
				case 6 :
					System.out.println("회원 관리 프로그램 종료합니다.");
					System.exit(0);
					default : 
				System.out.println("잘못 입력하였습니다.");
			
			}
		}

	}

}
