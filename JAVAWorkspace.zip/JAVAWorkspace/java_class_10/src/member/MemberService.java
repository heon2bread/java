package member;

public interface MemberService {
	
	public void memberList();
	
	public void memberInsert();
	
	public void memberView();
	
	public void memberEdit();
	
	public void memberDelete();

}
