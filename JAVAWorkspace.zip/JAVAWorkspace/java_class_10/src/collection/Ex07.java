package collection;

import java.util.*;

public class Ex07 {

	public static void main(String[] args) {
		
		// HashMap을 사용해서 아이디와 비밀번호 4개 넣기
		// <String, String> <아이디, 비밀번호>
		// keySet 메소드로 key 목록을 Set 타입으로 반환받은 후
		// Iterator를 사용해서 아이디와 비밀번호 출력하기
		
		Map<String, String> map = new HashMap<>();
		
		map.put("a", "1231");
		map.put("b", "1234");
		map.put("c", "1235");
		map.put("d", "1236");
		
		Set<String> keySet = map.keySet();
		
		Iterator<String> keyIter = keySet.iterator();
		
		while (keyIter.hasNext()) {
			String id = keyIter.next();
			String pw = map.get(id);
			System.out.println("아이디 : "+id +" / 비밀번호 : "+pw); 
			
		}

	}

}
