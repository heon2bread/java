package collection;

import java.util.*;

public class Ex03 {

	public static void main(String[] args) {
		
		LinkedList<String> list = new LinkedList<>();
		
		list.add("사과");
		list.add("포도");
		list.add("딸기");
		list.add("바나나");
		list.add("망고");
		
		Iterator<String> iter = list.iterator();
		// Iterator : 반복자
		// 컬렉션 객체의 iterator 메소드를 호출하여 객체를 얻어온다.
		
		while (iter.hasNext()) {
			// 컬렉션에 요소가 있는지 확인 후에 요소가 있다면 true, 없다면 false를 반환
			
			String str = iter.next();
			// 다음 요소를 얻어온다.
			System.out.println(str);
			
}
		System.out.println();
		// iterator는 1회성이다. 필요하면 다시 객체를 얻어와야 한다.
		iter = list.iterator();
		
		while(iter.hasNext()) {
			String str = iter.next();
			System.out.println(str);
			iter.remove(); // next 메소드로 가져온 객체를 삭제
		}
		System.out.println();
		if (list.isEmpty()) {
			System.out.println("비어있음");
		}
		
	}

}
