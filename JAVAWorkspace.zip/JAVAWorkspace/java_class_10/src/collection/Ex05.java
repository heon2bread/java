package collection;

import java.util.*;

public class Ex05 {

	public static void main(String[] args) {
		
		// String 타입의 HashSet을 생성한 후
		// 과일의 이름 5개를 넣는다.
		// 반복자(Iterator)를 사용하여 과일의 이름 하나씩 출력하기
		
		Set<String> fruit = new HashSet<>();
		
		fruit.add("사과");
		fruit.add("귤");
		fruit.add("키위");
		fruit.add("멜론");
		fruit.add("수박");
		
		Iterator<String> fruitIterator = fruit.iterator();
		
		while (fruitIterator.hasNext()) {
			
			String one = fruitIterator.next();
			System.out.print(one + " ");
		}
		

	}

}
