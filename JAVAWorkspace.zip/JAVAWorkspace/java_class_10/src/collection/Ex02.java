package collection;

import java.util.*;

public class Ex02 {

	public static void main(String[] args) {
		
		// String 타입의 ArrayList를 생성한 후
		// 연예인 5명의 이름을 넣어보자
		// 이름을 향상된 for문과 일반 for문으로 출력하기

		List<String> person = new ArrayList<>();
		
		person.add("김");
		person.add("이");
		person.add("박");
		person.add("최");
		person.add("홍");
		
		
		for (String name : person) {
			System.out.print(name + " ");
		}
		System.out.println();
		
		
		for (int i =0; i < person.size(); i++) {
			String name = person.get(i);
			System.out.println(i + " : " + name);
		}
		
	}

}
