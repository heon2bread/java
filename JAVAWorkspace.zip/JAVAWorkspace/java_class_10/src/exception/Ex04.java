package exception;

public class Ex04 {

	public static void main(String[] args) {
		
		try {
		method();
		}catch(ClassNotFoundException e) {
			System.out.println("클래스를 찾을 수 없습니다.");
			e.printStackTrace();
			System.out.println("메세지 : "+ e.getMessage());
		}finally {
			System.out.println("항상 실행됩니다!");
		}
		

	}
	
	public static void method() throws ClassNotFoundException{
							// throws : 호출한 곳에서 예외처리
		
		Class.forName("exception.Ex05");
		
	}

}
