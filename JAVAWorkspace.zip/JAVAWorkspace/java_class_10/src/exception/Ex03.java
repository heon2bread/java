package exception;

public class Ex03 {

	public static void main(String[] args) {
		
		try {
		
			System.out.println(1/0);
			
		}catch(ArithmeticException ae) {
			
			ae.printStackTrace();
			// 예외발생 당시의 호출 스택에 있는 메소드의 정보와 메세지를 화면에 출력해주는 메소드 
			
			System.out.println("메세지 : "+ae.getMessage());
			
		}
		
		
		
	}

}
