package exception;

public class Ex02 {

	public static void main(String[] args) {
		
		try {
			
//			System.out.println(1/0);
			
			System.out.println(args[0]);
			
		}catch(ArithmeticException ae) {
			
			System.out.println("0으로 나눌 수 없습니다!");
			
		}catch(ArrayIndexOutOfBoundsException aie) {
			
			System.out.println("index 범위를 벗어났습니다!");
			
		}catch(Exception e) {
			// ArithmeticException과
			// ArrayIndexOutOfBoundException 을 제외한 모든 예외처리
			
			System.out.println("Exception 예외가 발생하였습니다!");
			
		}
		
	}

}
