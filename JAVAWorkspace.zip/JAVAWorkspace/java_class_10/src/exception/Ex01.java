package exception;

public class Ex01 {

	public static void main(String[] args) {
		
//		system.out.println();
		// 컴파일 에러 : 컴파일 자체가 안됨
		// 자바컴파일러 : 번역(구문체크)
		
//		System.out.println(args[0]);
		// 실행에러 : 실행 중 발생
		
		try {
			// 예외가 발생할 가능성이 있는 코드를 작성
			System.out.println("Hello World~!");
			System.out.println(args[0]);
			System.out.println("예외가 발생되면 실행이 안됩니다.");
		}catch(Exception e) {
			// try 블록에서 예외가 발생되었을 시 예외처리 코드를 작성
			System.out.println("예외가 발생했습니다.");
		}finally {
			// 예외의 발생 여부에 상관없이 항상 실행 되어야 하는 코드를 작성\
			System.out.println("항상 실행이 됩니다.");
		}
		
		
		
	}

}
