package folder;

public class Practice {

	public static void main(String[] args ) {
		
		System.out.println("문자열 입니다.");
		System.out.println("문자열 안에 내용은 그대로 출력됩니다.");
		
		System.out.println("1+2");
		// "" 안에 넣은 내용은 그대로 출력
		
		System.out.println(1+2);
		// ()안에 값을 계산을 한 후 3을 출력
		
	}

}