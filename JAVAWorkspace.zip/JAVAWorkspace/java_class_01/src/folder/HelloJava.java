package folder;

public class HelloJava {

	public static void main(String[] args) {

		System.out.println("Hello World~!!!!");
		// Hello World~!!!!를 출력해주는 코드.
	}

}

// System.out. 출력 명령어
// ; 명령어가 끝났을 때
// public static void main(String[] args) 메인이라는 이름의 메소드
// class 객체(껍데기)를 만드는것
// {} 범위를 나타냄 (모든 코드는 {}범위 안에서 작성되어야함)
// "" 문자열. (""문자열 안에서는 주석 불가능)

// 한줄 주석 
// 주석은 프로그램에 영향을 주지 않는다.
// 주석은 소스내용 설명을 위한 코드. (즉 개발자를 위한 코드)
/* 범위 주석 */

// 이클립스에서 자주 사용하는 단축기
// tab : 들여쓰기
// shift + tab : 내어쓰기
// ctrl + shift + c : 라인주석 단축기
// ctrl + (+,-) : 폰트 크기 조절
// ctrl + space : 자동완성
// ex) sysout 후 ctrl + space > System.out.println();
// ctrl + shift + f : 자동정렬
