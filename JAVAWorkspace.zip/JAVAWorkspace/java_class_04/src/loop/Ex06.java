package loop;

public class Ex06 {

	public static void main(String[] args) {
		
		// 이중(중첩) for 문
		
		for(int i = 0; i < 10; i++) {
			
			for(int j = 0; j < 10; j++) {
				
				System.out.println("i : " + i + ", j : "+ j);
			}
		}

	}

}
