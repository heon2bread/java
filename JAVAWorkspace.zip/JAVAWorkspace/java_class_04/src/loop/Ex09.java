package loop;

import java.util.Scanner;

public class Ex09 {

	public static void main(String[] args) {
		
		// while문
		
		int i = 0;
		
		while(i < 5) { // 조건값이 true이면 무한반복
			
			System.out.println("while문 안입니다.");
			i++;
			
			
			
		}
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("10 + 20의 정답을 입력해주세요");
		
		System.out.print("정답 입력 : ");
		
		int answer = scan.nextInt();
		
		while (answer != 30) {
			System.out.println("정답이 틀렸습니다.");
			System.out.println("다시 10+20의 정답을 입력해주세요");
			System.out.print("정답 입력 : ");
			answer = scan.nextInt();
		}
		
		System.out.println("정답을 맞추셨습니다.");
		System.out.println("입력하신 정답은 : "+ answer +" 입니다.");
		
		scan.close();

	}

}
