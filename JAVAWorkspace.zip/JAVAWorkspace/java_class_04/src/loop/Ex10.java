package loop;

public class Ex10 {

	public static void main(String[] args) {
		
		// while문을 사용해서 1~10까지 합 구하기
		
		int i = 1;
		int sum = 0;
		
		while (i<11) {
			sum+=i;
			i++;
		}
		System.out.printf("1~10의 합은 %d입니다.",sum);

	}

}
