package loop;

public class Ex07 {

	public static void main(String[] args) {
		
//		for(int i = 1; i <=9; i++) {
//			
//			System.out.printf("2X%d=%d\n", i, 2*i);
//		}
		
		// 이중 for문을 사용해서 구구단 2단~9단 출력
		
		for(int j = 1; j <=9; j++) {
			for(int i = 2; i<10; i++) {
				System.out.printf("%dX%d=%d\t",i,j,i*j);
			}
			
			System.out.println();
		}	
		
		
			

	}

}
