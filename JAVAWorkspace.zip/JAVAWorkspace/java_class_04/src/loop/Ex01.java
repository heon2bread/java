package loop;

public class Ex01 {

	public static void main(String[] args) {
		
		// 반복문
		
//		System.out.println("1장을 복사했습니다.");
//		System.out.println("2장을 복사했습니다.");
//		System.out.println("3장을 복사했습니다.");
//		System.out.println("4장을 복사했습니다.");
//		System.out.println("5장을 복사했습니다.");
//		System.out.println("6장을 복사했습니다.");
//		System.out.println("7장을 복사했습니다.");
//		System.out.println("8장을 복사했습니다.");
//		System.out.println("9장을 복사했습니다.");
//		System.out.println("10장을 복사했습니다.");

		for(int i = 1; i<=10; i++) {
			System.out.println(i + "장을 복사했습니다.");
		}
		

	}

}
