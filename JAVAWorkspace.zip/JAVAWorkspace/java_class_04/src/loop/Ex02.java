package loop;

public class Ex02 {

	public static void main(String[] args) {
		
		// for문
		
		int i;
		
//		for(i=1; i<=5; i++) {
//			System.out.println("for문 안입니다. i : " + i);
//		}
//		
//		System.out.println("for문을 나왔습니다. i : " + i);
		
		
		
		// for문을 사용해서 2 4 6 8 10 출력
		for(i=2; i<11; i+=2) { 			// for문에서 사용된 변수는 {}블록 밖으로 나오면 사용 불가
										// {}밖에서도 사용하려면 밖에서 변수 선언해야함 	
			System.out.print(i+" ");
		}

	}

}
