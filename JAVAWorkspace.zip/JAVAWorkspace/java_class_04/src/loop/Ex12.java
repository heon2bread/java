package loop;

public class Ex12 {

	public static void main(String[] args) {
		
		int i = 100;
		
		do {
			
			System.out.println("처음 한번은 우선 실행한다.");
			
			
		}while(i==200); // 세미콜론 해준다.
		

	}

}
