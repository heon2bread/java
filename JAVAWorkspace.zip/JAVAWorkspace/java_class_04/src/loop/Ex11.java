package loop;

public class Ex11 {

	public static void main(String[] args) {
		
		// 이중(중첩) while문을 사용해서 구구단 2단~9단까지 출력
		
		int num = 1;
		
		while (num<10) {
			int dan = 2;
			while (dan<10) {
				System.out.printf("%dX%d=%d\t",dan,num,dan*num);
				dan++;
				
			}
			
			System.out.println();
			
//			int dan = 2;
			num++;
			
		}
		

	}

}
