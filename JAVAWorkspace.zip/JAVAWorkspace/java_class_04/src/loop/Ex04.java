package loop;

public class Ex04 {

	public static void main(String[] args) {
		
		// 0, 10, 20 ,30, 40, ... 90
		// if ~ else문을 사용해서 , 지우기
		
		for(int i=0; i<91; i+=10) {
			if(i !=90) {
				System.out.print(i+", ");}
				else {
					System.out.print(i);
				}
			}
			

	}

}
