package loop;

public class Ex03 {

	public static void main(String[] args) {
		
		// for문을 사용해서 1~10까지 합 구하기
		// 1 + 2 + 3 + ... + 10 = 55
		
		int sum=0;
		
		for(int i= 0; i < 11; i++) {
			
			sum+=i;
			
		}
		System.out.println(sum);
	}

}
