package loop;

import java.util.Scanner;

public class Ex15 {

	public static void main(String[] args) {
		
		// 커피숍 주문받기
		
		Scanner scan = new Scanner(System.in);
		
		int menu;
		
		do {
			
			System.out.println("커피메뉴 주문받겠습니다~!");
			System.out.println("---------------------------");
			System.out.println("## 1.아메리카노 2.카페라떼 ##");
			System.out.println("## 3.에스프레소 4.오렌지주스 ##");
			System.out.println("## 5.그만 주문하기        ##");
			System.out.println("---------------------------");
			menu = scan.nextInt();
			
			switch(menu) {
			
			case 1 :
				System.out.println("# 아메리카노 주문받았습니다!!");
				break;
			case 2 :
				System.out.println("# 카페라떼 주문받았습니다!!");
				break;
			case 3 :
				System.out.println("# 에소프레소 주문받았습니다!!");
				break;
			case 4 : 
				System.out.println("# 오렌지주스 주문받았습니다!!");
				break;
			case 5 :
				System.out.println("# 안녕하가세요~!!");
				break;
				default :
					System.out.println("잘못 주문 하셨습니다!!");
			}
			
		}while(menu != 5);
		
		
		

	}

}
