package condition;

import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("1~100점까지 중 점수를 입력 : ");
		
		int score = scan.nextInt();
		
		// switch문을 사용해서 A학점~F학점까지 나누기
		// 90~100 : A학점 출력
		// 80~89 : B학점 출력
		// 70~79 : C학점 출력
		// 60~69 : D학점 출력
		// 그 외 미만 : F학점
		
		score = score/10;
		char grade = ' ';
		
		switch(score) {
			
			case 10 :
			case 9 :
//					System.out.println("A학점 입니다.");
					grade= 'A';
					System.out.printf("학점은 %c입니다.", grade);
					break;
			case 8 :
//					System.out.println("B학점 입니다.");
					grade= 'B';
					System.out.printf("학점은 %c입니다.", grade);
					break;
			case 7 :
//					System.out.println("C학점 입니다.");
					grade= 'C';
					System.out.printf("학점은 %c입니다.", grade);
					break;
			case 6 :
//					System.out.println("D학점 입니다.");
					grade= 'D';
					System.out.printf("학점은 %c입니다.", grade);
					break;
					default :
//					System.out.println("F학점 입니다.");
					grade= 'F';
					System.out.printf("학점은 %c입니다.", grade);
							
			
		}

	}

}
