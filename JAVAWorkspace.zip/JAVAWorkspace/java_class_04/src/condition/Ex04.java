package condition;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int num1, num2, num3;
		int max, min;
		double avg;
		
		System.out.print("첫번째 정수를 입력하세요 : ");
		num1 = scan.nextInt();
		System.out.print("두번째 정수를 입력하세요 : ");
		num2 = scan.nextInt();
		System.out.print("세번째 정수를 입력하세요 : ");
		num3 = scan.nextInt();
		
		// 1. Scanner를 사용해서 3개의 정수를 입력받아
		// num1, num2, num3 변수에 저장하기
		// 2. if ~ else 문을 사용해서 3개의 정수중에서 
		// 가장 큰 수(최대값)를 찾아 max 변수에 저장하기
		// 2. if ~ else 문을 사용해서 3개의 정수중에서 
		// 가장 작은 수(최소값)를 찾아 min 변수에 저장하기
		// 4. 3개 정수의 평균을 구한 후 avg 변수에 저장하기
		
		if (num1 > num2 && num1 > num3 ) {
			max=num1; }
		else if (num2 > num3) {
				max=num2;}
			else { max=num3;
			}
		
		if (num1 < num2 && num1 < num3 ) {
			min=num1; }
		else if (num2 < num3) {
				min=num2;}
			else { min=num3;}
		
		avg= (num1+num2+num3)/3.0;
		
		System.out.println("최대값 : " + max);
		System.out.println("최소값 : " + min);
		System.out.println("평균 : " + avg);
		
		}

		
	}

