package condition;

import java.util.Scanner;

public class Ex03 {

	public static void main(String[] args) {
		
		// 정수 하나를 입력받아 int 변수에 저장하기
		// 입력받은 정수가 홀수인지 짝수인지 if ~ else문을 사용하여 알아보기
		
		Scanner scan = new Scanner(System.in);

		System.out.print("숫자 입력 : ");
		int num = scan.nextInt();
		
		if (num %2 == 0) {
			System.out.println("짝수입니다.");
			}
			else {
				System.out.println("홀수입니다.");
			}
		
		scan.close();
	
		
	}

}
