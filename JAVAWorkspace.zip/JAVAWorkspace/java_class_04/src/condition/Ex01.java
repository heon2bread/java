package condition;

public class Ex01 {

	public static void main(String[] args) {
		
		int a = 83;
		
		if(a != 85) { // true 일 때 중괄호 실행
			
			System.out.println("if문 안입니다.");
			System.out.println("조건은 참 입니다.");
			
		}

		System.out.println("if문과는 상관없이 실행"); 
		
	}

}
