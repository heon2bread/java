package condition;

import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		
		// 정수 3개를 입력받아 작은수로 나열하기
		
		Scanner scan = new Scanner(System.in);
		
		int num1, num2, num3;
		int temp;
		
		System.out.print("첫번째 정수 입력 : ");
		num1 = scan.nextInt();
		
		System.out.print("두번째 정수 입력 : ");
		num2 = scan.nextInt();
		
		System.out.print("세번째 정수 입력 : ");
		num3 = scan.nextInt();
		
		// if 문과 temp 변수를 사용하여 num1을 가장 작은 수로 만들기
		// 그 다음 작은 수는 num2로 만들기
		// 가장 큰수는 num3으로 만들기
		
		if(num1 > num2) { // 수바꾸기
			temp = num1;
			num1 = num2;
			num2 = temp;
		}
		
		if(num1 > num3) {
			temp = num1;
			num1 = num3;
			num3 = temp;
		}
		
		if(num2 > num3) {
			temp = num2;
			num2 = num3;
			num3 = temp;
			
		}
			
		System.out.printf("작은수로 정렬 : %d, %d, %d\n", num1, num2, num3);

	}

}
