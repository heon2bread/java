package variable;

public class Ex05 {

	public static void main(String[] args) {
		
		// 나이, 키 , 몸무게를 변수로 선언하고
		// 초기화해서 출력해보기
		
		int age = 28;
		int height = 175;
		int weight = 60;
		
		System.out.println(age);
		System.out.println(height);
		System.out.println(weight);

	}

}