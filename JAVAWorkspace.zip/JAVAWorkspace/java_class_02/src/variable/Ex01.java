package variable;

public class Ex01 {

	public static void main(String[] args) {
		
		int a; // 정수 타입의 변수 선언
		
		a = 100; // 선언 후 저장 : 초기화
		// = 은 오른쪽의 값(데이터)을 왼쪽 변수에 저장한다.
		
		// int a = 200; // 오류 발생
		// a = 200; // 오류 발생하지 않음
		// 같은 이름의 변수가 2개가 있으면 프로그램에서는 어떤 변수를 골라야하는지 모른다.
		
		int b;
		b = 200;
		
		System.out.println(a);
		System.out.println(b);
		
		int c = 300; // 선언과 동시에 초기화
		int d = 400;
		
		System.out.println(c);
		System.out.println(d);
		
	}

}
