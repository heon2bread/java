package variable;

public class Ex08 {

	public static void main(String[] args) {
		
		
		byte a = 65;
		char ch = (char)a; // 강제 타입변환 // 캐스팅
		System.out.println(ch); // A 출력
		
		int b = 128;
		byte c = (byte)b; // 강제 타입변환
//		지정된 타입보다 값이 더 클 경우 강제 타입변환을 하면
//		OverFlow : 가장 작은 값으로 돌아간다.
		System.out.println(c); // -128 출력
		
		float d = 3.14f;
		int e = (int)d;
//		실수를 정수로 강제 타입변환을 하면 정수부분만 저장된다.
		System.out.println(e); // 3 출력
		
	}

}