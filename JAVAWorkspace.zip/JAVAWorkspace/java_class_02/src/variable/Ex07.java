package variable;

public class Ex07 {

	public static void main(String[] args) {
		
		
		byte a = 100;
		int b = a; // 자동 타입 변환

		System.out.println(b);
		
//		char ch = (char)a;
		// 음수가 저장될 수 있는 byte 타입을 음수가 저장될 수 없는 char 타입으로 자동 타입변환 할 수 없다.
		
		byte c = 10;
		byte d = 20;
		
//		byte result1 = c + d;
//		기본적으로 정수 연산은 int 타입으로 진행되기 때문에 오류발생
		
		int result2 = c + d; // 자동 타입변환
		System.out.println(result2);
		
		int e = 10;
		double f = 10.2;
		
		double result3 = e+f;
		// int 타입 피연산자가 double 타입으로 자동 타입변환되고 연산을 수행
		
		System.out.println(result3);
		
	}

}
