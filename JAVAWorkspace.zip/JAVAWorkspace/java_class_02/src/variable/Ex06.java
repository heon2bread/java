package variable;

public class Ex06 {

	public static void main(String[] args) {

//		byte a = 128; // 지정된 크기보다 더 큰 수를 담을 수 없다.
		
		byte b = 127;
		byte c = -128;
		
		System.out.println(b);
		System.out.println(c);
		
		long d = 1234567891234567891L;
		float f = 123456789123456789123F;
		// 실수는 정수보다 더 큰 수가 표현이 가능하다.
		
		System.out.println(d);
		System.out.println(f);
		
		double g = 3e2; // 300.0, 3x10의 2승
		double h = 5e-3; // 0.005, 5x10의 -3승
		System.out.println(g);
		System.out.println(h);

	}

}
