package variable;

public class Ex04 {

	public static void main(String[] args) {
		
		boolean bool1 = true;
		boolean bool2 = false;
		
		System.out.println(bool1);
		System.out.println(bool2);
		
		System.out.println(1 < 5);
		// 1이 5보다 작다.
		System.out.println(3 > 9);
		// 3이 9보다 크다.
		
		// 비교 연산자는 boolean값(논리 연산값)을 갖는다.
		

	}

}
