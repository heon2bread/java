package variable;

public class Ex02 {

	public static void main(String[] args) {
		
		// 변수명
		
		int price1 = 100;
		int $price = 200;
		int _price = 300;
		// int #price = 400;
		// 변수명 $나 _외에 다른 특수 기호는 사용 불가하다.
		// int 1price = 500;
		// 숫자로 시작할 수 없다.
		
		System.out.println(price1);
		System.out.println($price);
		System.out.println(_price);
		
		String firstname = "JAVA";
		// 자바에서 문자열은 ""이다.
		// 문자열을 저장하는 타입은 String
		
		String firstName = "자바";
		// 자바의 변수는 대소문자를 구별한다.
		
		System.out.println(firstname);
		System.out.println(firstName);
		
//		int 한글 = 1;
//		int 洪 = 2;		
		

	}

}
