package variable;

public class Ex03 {

	public static void main(String[] args) {
		
		
		byte a = 100; // 1바이트
		short b = 200; // 2바이트
		
		char c1 = 'A'; // 2바이트
//		문자는 작은 따옴표를 쓴다. 문자열은 큰 따옴표 사용
		char c2 = 65;
//		내부적으로 정수로 저장되기 때문에 오류 발생하지 않음
//		아스키 ascii 코드에서 65는 A를 표현

		int d = 1000; // 4바이트
		long e = 12345678123456789L; // 8바이트, l L 붙여줘야됨
		
		float f = 3.14f; // 4바이트, f F 붙여줘야됨
		double g = 3.141592;
		
		boolean h = true; // 1바이트
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c1);
		System.out.println(c2);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		System.out.println(h);

	}

}
