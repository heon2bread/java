package print;

public class Ex02 {

	public static void main(String[] args) {
		
		System.out.printf("정수 : %d\n", 100);
		System.out.printf("실수 : %.2f\n", 3.14);
		System.out.printf("문자 : %c\n", 'A');
		System.out.printf("문자열 : %s\n", "Hello World");
		System.out.println();
		
		// %문자 : 서식 문자 >> printf()에서만 사용 가능
		// %d : 정수 
		// %f : 실수
		// %c : 문자
		// %s : 문자열
		
		System.out.printf("%5d\n", 123);
		System.out.printf("%-5d\n", 123);
		System.out.printf("%.2f\n", 12.1234); // 반올림 됨
		System.out.printf("%7.2f\n", 12.1234);

	}

}
