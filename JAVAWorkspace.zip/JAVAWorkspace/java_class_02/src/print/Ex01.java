package print;

public class Ex01 {

	public static void main(String[] args) {
		
		System.out.print("()안에 내용을 출력 후 줄바꿈 x");
		System.out.print("확인!");
		
		System.out.println();
		// 이렇게만 그대로 쓰면 줄바꿈만 한다.

		System.out.printf("이름 : %s\n", "박제헌");
		// printf() : ()안에 첫번째 문자열 형식대로 내용 출력
		
		System.out.printf("나이 : %d\n", 28);
		
		System.out.printf("%d, %d, %d\n", 100, 200, 300);
		
		System.out.printf("이름 : %s\t 나이 : %d\n", "박제헌",28);
		
	}

}
