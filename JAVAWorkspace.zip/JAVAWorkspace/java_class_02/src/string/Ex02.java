package string;

public class Ex02 {

	public static void main(String[] args) {
		// 문자열 : String
		// String은 기본 자료형처럼 다루게 해주는 class이다.
		
		String name = "\"홍길동\"";
		
		System.out.println(name);
		
		String str = "이몽룡과\t성춘향은\n사랑하는\\사이다.";
		
		System.out.println(str);

	}

}
