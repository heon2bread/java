package string;

public class Ex01 {

	public static void main(String[] args) {
		
		// 이름, 전화번호, 이메일주소를 String 변수에 저장 후 
		// 콘솔뷰에 출력하기
		
		String name = "박제헌";
		String number = "010-2065-8077";
		String email = "wpgjs1996@naver.com";
				
		System.out.println(name);
		System.out.println(number);
		System.out.println(email);		
		

	}

}
