package method;

public class Ex06 {

	public static void sum1(int... n) { // 매개값을 가변적으로 받을 때
		
		int sum = 0;
		
		for(int i : n) { // 향상된 for문
			sum+=i;
		}
		
		System.out.println("매개값들의 합 : " + sum);
		
	}
	
	public static void sum2(int[]array) { // 매개값이 배열로 들어오는 경우
		
		int sum = 0;
		
		for (int i : array) {
			sum+=i;
			}
		System.out.println("매개들의 합 : "+sum);
		
	}
	
	public static int[] numbers() {
		int[] number = {10,20,30,40,50};
		return number;
	}
	
	public static void main(String[] args) {
		
		sum1(2,3,4);
		
		int[] array= {1,2,3,4,5};
		sum2(array);
		
		int[] array2 = numbers();
		sum2(array2);

	}

}
