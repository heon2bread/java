package method;

public class Ex01 {

	
	public static void method1() {
		System.out.println("void 형 메소드는 돌려줄 값이 없음");
	}
	
	public static int method2() {
		System.out.println("리턴타입은 int 형인 메소드");
		int a = 100;
		return a;
	}
	
	public static void main(String[] args) {
		
		System.out.println("main 메소드 입니다,"); // ctrl+f11 main이 적혀있는 메소드를 먼저 출력
		
		method1(); // void형 메소드 호출
		int a = method2(); // int형 리턴 타입 메소드 호출 // int a = 100;
		System.out.println("method2에서 돌려준 값 : "+a);

	}

}
