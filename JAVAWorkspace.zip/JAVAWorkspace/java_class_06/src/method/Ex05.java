package method;

import java.util.Scanner;

public class Ex05 {

	// 1. 전원을 켭니다. 출력해주는 powerOn 메소드 만들기
	// 2. 전원을 끕니다. 출력해주는 powerOff 메소드 만들기
	
	// 3. 정수 2개를 매개변수로 받아 받은 정수 값은 더한 후 결과를 반환해주는 add 메소드 만들기
	// 4. 정수 2개를 매개변수로 받아 받은 정수 값은 뺀 후 결과를 반환해주는 subtract 메소드 만들기
	// 5. 정수 2개를 매개변수로 받아 받은 정수 값은 곱한 후 결과를 반환해주는 multiply 메소드 만들기
	// 6. 실수 2개를 매개변수로 받아 받은 실수 값은 나눈 후 결과를 반환해주는 divide 메소드 만들기
	// 7. 정수 하나를 매개변수로 받아 그 결과 값을 출력해주는 outPut 메소드 만들기
	// 8. 실수 하나를 매개변수로 받아 그 결과 값을 출력해주는 outPut 메소드 만들기
	
	public static void powerOn() {
		System.out.println("전원을 켭니다.");
	}
	
	public static void powerOff() {
		System.out.println("전원을 끕니다.");
		System.exit(0);
	}
	
	public static int add(int a, int b) {
		System.out.println(a+"+"+b+"="+(a+b));
		return a+b;
	}
	
	public static int subtract(int a, int b) {
		System.out.println(a+"-"+b+"="+(a-b));
		return a-b;
	}
	
	public static int multiply(int a, int b) {
		System.out.println(a+"*"+b+"="+(a*b));
		return a*b;
	}
	
	public static double divide(double a, double b) {
		System.out.println(a+"/"+b+"="+(a/b));
		return a/b;
	}
	
	public static void outPut(int result) {
		System.out.println("결과 = "+result);
	
	}
	
	public static void outPut(double result) {
		System.out.println("결과 = "+result);

	}
	
	
	public static void main(String[] args) {
	
		Scanner scan = new Scanner(System.in);
		
		powerOn();
		
		while(true) {
			
			System.out.println("---------------------");
			System.out.println("1.더하기 2.빼기 3.곱하기");
			System.out.println("4.나누기 5.프로그램 종료하기");
			System.out.println("---------------------");
			int choice = scan.nextInt();
			
			if(choice==5) {
				powerOff();
			}
			System.out.print("첫번째 계산할 수 : ");
			int a = scan.nextInt();
			
			System.out.print("두번째 계산할 수 : ");
			int b = scan.nextInt();
			
			switch (choice) {
			
			case 1:
				outPut(add(a,b));
				break;
			case 2:
				outPut(subtract(a,b));
				break;
			case 3:
				outPut(multiply(a,b));
				break;
			case 4:
				outPut(divide(a,b));
				break;
				default :
					System.out.println("잘못 입력하였습니다.");
				
			}
		}
		

	}

}
