package method;

public class Ex08 {

	// 재귀 함수란 : 함수안에 자신의 함수를 다시 호출하는 함수를 의미한다.
	
	// 재귀 함수는 함수 내에서 자기 자신을 계속 호출하는 방식이기 때문에 함수 안에서 종료가 되는 코드를 생각하며 코드를 구현해야 한다.
	
	public static void hello(int num) {
		
		if(num==0) {
			return;
		} else {
			System.out.println("Hello World!!!");
			hello(num-1);
		}
		
	}
	
	public static void main(String[] args) {
		
		hello(5);

	}

}
