package clazz.array;

import java.util.Scanner;

// Member 클래스를 만든다.
// 필드는 private String name; private int age; private String tel;
// 생성자의 매개변수로 매개값을 받아 필드 초기화를 한다.
// 필드에 대한 getter/ setter 메소드를 만든다.

class Member {
	
	private String name;
	private String tel;
	private int age;
	
	public Member(String name, String tel, int age) {
		this.name = name;
		this.tel = tel;
		this.age = age;
		
	}
	
	public void setName(String name) {
		this.name=name;
	}
	public String getName() {
		return name;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getTel() {
		return tel;
	}
	public void setAge(int age) {
		this.age=age;
	}
	public int getAge() {
		return age;
	}
	
	
}

class MemberService {
	// 필드
	Member[] members;
	Scanner scan = new Scanner(System.in);
	
	// 생성자
	public MemberService(int memberSu) {
		members = new Member[memberSu];
	} 
	
	// 메소드
	public void memberInsert() {
		
		// 반복문(Member 배열의 길이만큼 반복)을 사용해서 회원의 이름, 나이, 전화번호를 입력받아
		// Member 객체를 생성 후 Member 배열의 각 요소에 저장하기
			for (int i = 0; i < members.length; i++) {
				System.out.print(i+1+"번째 이름을 입력하세요 : ");
				String name = scan.next();
				System.out.print(i+1+"번째 나이를 입력하세요 : ");
				int age = scan.nextInt();
				System.out.print(i+1+"번째 전화번호를 입력하세요 : ");
				String tel = scan.next();
				
				members[i] = new Member(name, tel, age);
		
		}
		
	}
	
	public void memberList() {
		System.out.println("------------------------------------------------");
		// 반복문을 사용하여 회원의 이름, 나이, 전화번호 출력하기
		for (int i = 0; i < members.length; i++) {
			
			String name = members[i].getName();
			int age = members[i].getAge();
			String tel = members[i].getTel();
			
			System.out.println(i+1+"번째 회원의 이름, 나이, 전화번호입니다.");
			System.out.println("|| 이름 : "+ name+
				                "| 나이 : " + age + "| 전화번호 : " + tel + "||"); 
			
			
		}
		System.out.println("------------------------------------------------");
	}
	
	public void memberEdit() {
		// Scanner로 회원의 번호(index)를 입력 받아 해당 회원의 나이와 전화번호를 수정하기
		// getter / setter 메소드 사용
		memberList();
		
		System.out.println("몇번째 회원의 정보를 수정할까요?");
		System.out.println("입력 : ");
		int su = scan.nextInt();
		
		System.out.println(su + "번째 회원의 정보를 수정합니다.");
		System.out.println(members[su-1].getName()+"님의 나이는 : " + members[su-1].getAge()+"살 입니다.");
		
		System.out.print("수정할 나이 : ");
		int age = scan.nextInt();
		
		System.out.println(members[su-1].getName()+"님의 전화번호는 : " + members[su-1].getTel()+"번 입니다.");
		
		System.out.print("수정 할 전화번호 : ");
		String tel = scan.next();
		
		members[su=1].setAge(age);
		members[su=1].setTel(tel);
		
		System.out.println(members[su-1].getName()+"님의 정보가 수정되었습니다.");
		
	}
}

public class Ex02 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("등록 할 회원 수 입력 : ");
		int memberSu = scan.nextInt();
		
		MemberService service = new MemberService(memberSu);
		
		service.memberInsert();
		
		while(true) {
			
			System.out.println("------------------------------");
			System.out.println("## 1.회원목록 2.회원정보 수정 3.종료");
			System.out.println("------------------------------");
			System.out.print("선택 : ");
			int choice = scan.nextInt();
			
			switch (choice) {
			case 1 :
				service.memberList();
				break;
			case 2 :
				service.memberEdit();
				break;
			case 3 :
				System.out.println("프로그램 종료합니다.");
				System.exit(0);
				default :
					System.out.println("잘못 입력하였습니다.");
			}
		}
		
		

	}

}
