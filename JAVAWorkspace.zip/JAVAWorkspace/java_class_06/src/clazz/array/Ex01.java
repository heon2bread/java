package clazz.array;

class Book {
	
	String title;
	String author;
	
	public Book(String title, String author) {
		this.title=title;
		this.author=author; // 필드 초기화
	}
	
	public void showInfo() {
		System.out.println(title + " : "+author); // 필드 출력
	}
	
}

public class Ex01 {

	public static void main(String[] args) {
		
		Book[] books = new Book[5];
		// 길이가 5인 Book 타입의 배열을 생성
		
		books[0] = new Book("JAVA","홍길동");
		books[1] = new Book("JSP","성춘향");
		books[2] = new Book("SPRING","이순신");
		books[3] = new Book("C언어","이몽룡");
		books[4] = new Book("DataBase","장보고");
		// 배열의 각 요소에 객체를 생성해서 주소값을 넣어준다.
		
		System.out.println(books[0].title);
		System.out.println(books[2].author);
		// 배열의 각 요소는 객체이기 때문에
		// 그 객체가 사용가능한 필드, 메소드를 사용할 수 있다.
		System.out.println();
		
		for(int i =0; i < books.length; i++) {
			books[i].showInfo();
		}
		
	}

}