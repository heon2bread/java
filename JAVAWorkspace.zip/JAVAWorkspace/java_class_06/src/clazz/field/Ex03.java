package clazz.field;

class Car2 {
	
	String color;
	int speed;
	
	// setter 메소드 : 필드 값 초기화 해주는 메소드
	public void setColor(String color) {
/*내 자신을 가리키는 참조변수 this*/ this.color = color;
	}
	
	// getter 메소드 : 필드 값 얻을 수 있는 메소드
	public String getColor() {
		return color;
	}
	
	
	public void setSpeed(int speed) {
		this.speed=speed;
	}
	
	public int getSpeed() {
		return speed;
	}
	

}

public class Ex03 {

	public static void main(String[] args) {
		
		Car2 myCar = new Car2();
		
		// 필드를 바로 접근
		
		 myCar.color = "빨강";
		 System.out.println("자동차 색상 : "+myCar.color);
		 
		 myCar.speed =  200;
		 System.out.println("현재 속도 : "+myCar.speed);
		 
		 // 필드를 메소드로 접근
		 
		 myCar.setColor("파랑");
		 System.out.println("자동차 색상 : "+myCar.getColor());
		 
		 myCar.setSpeed(100);
		 System.out.println("현재 속도 : "+myCar.getSpeed());
		 
		
		

	}

}
