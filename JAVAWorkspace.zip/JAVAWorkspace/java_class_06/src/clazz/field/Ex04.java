package clazz.field;

class Car3 {
	
	private int speed;
	private String color;
	// private : 외부 접근 금지
	// 필드를 바로 접근 X
	// 데이터 보호를 위해 사용
	
	public int getSpeed() {
		if(speed<30) {
			System.out.println("속도는 최소 30이어야 합니다.");
			System.out.println("속도를 30으로 세팅합니다.");
			speed = 30;
		}
		return speed;
	}
	public void setSpeed(int speed) {
		
		if (speed<0 || speed > 200) {
			return;
		}else {
			this.speed = speed;
		}
		
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	
}

public class Ex04 {

	public static void main(String[] args) {
		
		Car3 myCar = new Car3();
		
//		myCar.speed = 100;
//		
//		System.out.println("내 자동차 속도 : "+myCar.speed);
		
		myCar.setSpeed(50);
		System.out.println("내 자동차 속도 : "+myCar.getSpeed());
		
		myCar.setColor("파랑");
		System.out.println("내 자동차 색상 : "+myCar.getColor());

	}

}
