package clazz.field;


// Person 클래스 만든다.
// 필드는 String name; int age; 로 하고 외부접근 금지가 되게
// private로 설정한다.
// 필드에 대한 getter / setter 메소드를 만든 후 나이를 20~60살까지만 초기화 할 수 있도록 setAge 메소드를 수정한다.

class Person {
	private String name;
	private int age;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void setAge(int age) {
		if (age<20 || age>60) {
			System.out.println("나이는 20~60살까지만 가능합니다.");
			System.out.println("20살로 초기화합니다.");
			this.age=20;
		}else {
			this.age = age;
		}
		
	}
	public int getAge() {
		return age;
	}
}

public class Ex05 {
	
	public static void main(String[] args) {
		
		Person person = new Person();
		
		person.setName("홍길동");
		person.setAge(22);

		System.out.println("이름 : "+person.getName());
		System.out.println("나이 : "+person.getAge());
	}

}
