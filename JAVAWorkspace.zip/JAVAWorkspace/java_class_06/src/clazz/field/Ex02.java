package clazz.field;

class Car {
	// 필드
	String company = "현대자동차";
	String model = "그랜저";
	String color;
	int maxSpeed;
	int speed = 100;
	
	// 메소드
	public void run() {
		System.out.printf("%s가 %d속도로 달립니다.\n",model,speed);
	}
	
}

public class Ex02 {

	public static void main(String[] args) {
		
		// 1. Car 클래스로부터 Car 객체 생성하기
		// 2. Car 객체 사용하기 [필드 출력, 메소드 호출]
		
		Car myCar = new Car();
		
		System.out.println("제작 회사 : "+myCar.company);
		System.out.println("모델 : "+myCar.model);
		System.out.println("색상 : "+myCar.color);
		System.out.println("최고 속도 : "+myCar.maxSpeed);
		System.out.println("현재 속도 : "+myCar.speed);
		System.out.println();
		
		myCar.run();
		

	}

}
