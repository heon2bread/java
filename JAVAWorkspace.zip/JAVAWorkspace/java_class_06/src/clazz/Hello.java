package clazz;

// 하나의 소스파일에는 하나의 class만 작성하는 것이 좋다.


// 소스파일의 이름은 public class 이름과 일치해야한다.
public class Hello {}

// 하나의 소스파일에 여러 class를 선언할 수 있다.
// 하나의 소스파일에는 하나의 public class만 허용
/*public*/ class Hello2 {}

class Hello3 {}


