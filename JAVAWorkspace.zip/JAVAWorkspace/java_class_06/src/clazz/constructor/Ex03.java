package clazz.constructor;

// Car 클래스를 만든다.
// 필드는 private String color; private int speed; 이다.
// 생성자에서 매개변수로 매개값을 받아 필드 초기화를 한다.
// 속도가 30미만이거나 200을 초과할 겨우 속도를 50으로 셋팅한다.
// 필드를 출력해주슨 carProfile 메소드를 만들어서 생성자에서 필드 초기화를 한 후에 메소드를 호출해보자.


class Car {
	private String color;
	private int speed;
	
	public Car(String color, int speed) { 
			this.color= color;
			if(speed< 30 || speed > 200) {
				System.out.println("속도는 30이상 200이하여야 합니다.");
				System.out.println("속도를 50으로 셋팅합니다.");
				this.speed = 50;
			}else {
				this.speed = speed;
			}
			
			carProfile();

	}
	
	public void carProfile () {
		System.out.println("자동차 색상 : " + color);
		System.out.println("자동차 속도 : " + speed);
		System.out.println();
	}
	
}

public class Ex03 {

	public static void main(String[] args) {
		
		new Car("블랙",10);

	}

}
