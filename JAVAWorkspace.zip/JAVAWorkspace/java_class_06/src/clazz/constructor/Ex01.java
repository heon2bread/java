package clazz.constructor;

class Student {
	
	// 필드 
	String school = "IT학교";
	int studentID;
	String name;
	int age;
	
	// 생성자
	// 1. 생성자를 명시하지 않으면 자바컴파일러는 기본 생성자를 만들어준다.
	// 2. 하지만 생성자를 명시하면 만들지 않는다.
	// 3. 생성자는 메소드와 비슷하지만 반환타입이 없고, 클래스 이름과 같은 이름이다.
	public Student(int studentID, String name, int age) { // 생성자
		this.studentID = studentID;
		this.name = name;
		this.age = age;
	}
	
	public void profile() {
		System.out.println("-------------------");
		System.out.println("학교 : " + school);
		System.out.println("학번 : " + studentID);
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("-------------------");
	}
	
}

public class Ex01 {

	public static void main(String[] args) {
		
		Student student = new Student(202301, "홍길동", 20);
		// 클래스 타입 | 클래스 변수 = new | 생성자 
		
		student.profile();
		
		System.out.println();
		
		Student student2 = new Student(202205, "성춘향", 21);

		student2.profile();

	}

}