package clazz;


class Person { // class - 설계도
	
	// 클래스 안에 구성 멤버는 필드, 생성자, 메소드

	// 필드 (객체의 속성)
	// class에 선언된 변수를 필드라고 한다.
	String name;
	int age;
	
	// 생성자 (객체 초기화를 담당)
	// 생성자는 class 이름과 같은 이름이다.
	public Person() {}
	
	// 메소드 (객체의 기능)
	public void eat() {}
	public void run() {}
	
}


public class ClassMain {

	public static void main(String[] args) {
		
		Person object = new /*객체생성*/ Person(); // heap 힙 영역에 메모리 생성.
		// 클래스 클래스변수 = new 생성자
		
		System.out.println(object);

	}

}
