package operation;

public class Ex01 {

	public static void main(String[] args) {
		
		int i, j;
		
		i = +100;
		j = -200;
		System.out.println(i+j);
		
		// 증감 연산자의 독립 사용일때
		int x = 1;
		int y = 1;
		
		System.out.printf("x : %d, y : %d\n\n", x,y);
		x++;
		y = x;
		System.out.printf("x : %d, y : %d\n\n", x,y);
		
		--x;
		y = x;
		System.out.printf("x : %d, y : %d\n\n", x,y);
		
		// 증감 연산자의 독립 사용이 아닐 때
		y = ++x;
		// 연산과정 : x를 1증가 후에 y = x를 실행
		System.out.printf("x : %d, y : %d\n\n", x,y);
		
		y= x++;
		// 연산과정 : y = x를 실행 후에 x를 1증가
		System.out.printf("x : %d, y : %d\n\n", x,y);

	}

}
