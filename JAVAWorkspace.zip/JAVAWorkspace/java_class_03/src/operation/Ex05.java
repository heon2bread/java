package operation;

import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		
		int a, b;
		int result;
		
		// Scanner를 사용해서 두 정수를 입력 받아 a, b한테 저장 후
		// 사칙연산 계산을 하여 출력하기
		
		Scanner scan = new Scanner(System.in);
				
				System.out.print("첫번째 정수 입력 : ");
				a = scan.nextInt();
				System.out.print("두번째 정수 입력 : ");
				b = scan.nextInt();
				
				result=a+b;
				System.out.printf("a+b=%d\n",result);
				
				result=a-b;
				System.out.printf("a-b=%d\n",result);
				
				result=a*b;
				System.out.printf("a*b=%d\n",result);
				
				result=a/b;
				System.out.printf("a/b=%d",result);
				
				double result2;
				
				result2 = (double)a / (double)b;
				System.out.printf("%d / %d = %.2f\n",a,b,result2);
				
				scan.close();
				
	}

}
