package operation;

import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		
		// 3항(조건) 연산자
		
//		String str = (10 < 20) ? "10이 20보다 작습니다." : "10이 20보다 큽니다.";
//		
//		System.out.println(str);
		
		// 1~100 까지 정수 1개를 입력받아 변수에 저장하기
		// 3항(조건)연산자를 사용해서
		// 해당 정수가 80점 이상이면 합격입니다. 출력
		// 해당 점수가 80점 미만이면 불합격입니다. 출력

		Scanner scan = new Scanner(System.in);
		
		System.out.print("1~100까지 점수를 입력하세요 : ");
		int number = scan.nextInt();
		
//		String str = (number < 80) ? "불합격입니다." : "합격입니다.";
			
		System.out.println((number < 80) ? "불합격입니다." : "합격입니다.");
		
	}

}