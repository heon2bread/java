package operation;

public class Ex03 {

	public static void main(String[] args) {
		
		String str = "문자열을 " + "결합";
		
		System.out.println(str);
		
		System.out.println(2+"학년 "+10+"반");
		// 한쪽이 문자열이면 +연산자는 문자열결합 연산자로
		// 사용되어 다른 피연산자를 문자열로 변환을 하고 결합한다.
		
		System.out.println("홍길동 나이 : " + (2 + 10 + 5) + "살");
		

	}

}
