package operation;

import java.util.Scanner;

public class Ex06 {

	public static void main(String[] args) {
		
		// 동전 교환하기
		
		Scanner scan = new Scanner(System.in);
		
		int money, c500, c100, c50, c10;
		
		System.out.print("동전으로 교환할 돈 입력 : ");
		money = scan.nextInt();
		
		// 예 : 1870원 입력 > 500원 3개, 100원 3개, 50원 1개, 10원 2개
		// 각각의 동전의 갯수를 구한 후에 해당 변수에 저장하기
		
		c500 = money/500;
		money= money%500;
		System.out.println("500원 동전 : " + c500 + "개");
		c100 = money/100;
		money %= 100;
		System.out.println("100원 동전 : " + c100 + "개");
		c50 = money/50;
		money %= 50;
		System.out.println("50원 동전 : " + c50 + "개");
		c10 = money/10;
		money %= 10;
		System.out.println("10원 동전 : " + c10 + "개");
		System.out.println("바꾸지 못한 잔돈 : " + money + "원");
		
	}

}
